const mongoose = require("mongoose");

const InvestorDetailsSchema = new mongoose.Schema(
  {
    investorcompanyName: String,
    firstName: String,
    lastName: String,
    emailid: { type: String, unique: true },
    mobileNo: String,
    password: String,
    about:String,
    website:String,
    linkedin:String,
    location:String,
    investmentSector:String
  },
  {
    collection: "InvestorInfo",
  }
);

mongoose.model("InvestorInfo", InvestorDetailsSchema);