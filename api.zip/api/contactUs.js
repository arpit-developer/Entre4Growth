const mongoose = require("mongoose");

const contactUsSchema = new mongoose.Schema(
  {
    fullName: String,
    email: { type: String, unique: true },
    message: String
  },
  {
    collection: "contactUs",
  }
);

mongoose.model("contactUs", contactUsSchema);