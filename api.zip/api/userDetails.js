const mongoose = require("mongoose");

const UserDetailsSchema = new mongoose.Schema(
  {
    companyName: String,
    firstName: String,
    lastName: String,
    workemail: { type: String, unique: true },
    mobileNo: String,
    password: String
  },
  {
    collection: "UserInfo",
  }
);

mongoose.model("UserInfo", UserDetailsSchema);