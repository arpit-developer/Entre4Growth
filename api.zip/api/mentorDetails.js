const mongoose = require("mongoose");

const MentorDetailsSchema = new mongoose.Schema(
  {
    fullName: String,
    jobPost:String,
    email:{unique:true,type:String},
    mobileNo:String,
    password:String,
    aboutInfo:String,
  },
  {
    collection: "MentorsInfo",
  }
);

mongoose.model("MentorsInfo", MentorDetailsSchema);