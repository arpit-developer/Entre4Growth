app.post("/post", async (req, res) => {
    console.log(req.body);
    const { data } = req.body;
    try {
      if (data == "Arpit") {
        res.send({ status: "ok" });
      } else {
        res.send({ status: "User Not Found" });
      }
    } catch (error) {
      res.send({ status: "Something Went wrong" });
    }
  });
  