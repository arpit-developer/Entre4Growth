const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const bodyParser = require('body-parser');
const PitchBusiness = require("./PitchBusiness");
//app.use(express.json());
app.use(bodyParser.json());
app.use(cors());

const JWT_SECRET = "vdgfdsfgvgrer45yghh5yhfgdhgdfghfgbnfdnfnfnfnfdferrthtytyjadbmko" ;
const mongoURI =
  "mongodb+srv://entre4growth:henrycavill@mycluster.dp8ilry.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.once("open", () => {
  console.log("Connected to MongoDB database");
});
//SignUp API

require("./userDetails");

const User = mongoose.model("UserInfo");
app.post("/signup-user", async (req, res) => {
  const { companyName, firstName, lastName, workemail, mobileNo, password } =
    req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const oldUser = await User.findOne({ workemail });
    if (oldUser) {
      return res.json({ error: "User Exists" });
    }
    await User.create({
      companyName,
      firstName,
      lastName,
      workemail,
      mobileNo,
      password: hashedPassword,
    });
    res.send({ status: "ok" });
  } catch (error) {
    res.send({ status: "error" });
  }
});

//LOgin User API
app.post("/login-user", async (req, res) => {
  const { workemail,password} =req.body;
  const user = await User.findOne({workemail});
  if(!user){
    return res.json({error:"User Not Found"});
  }
  if (await bcrypt.compare(password, user.password)) {
    const token = jwt.sign({ workemail: user.workemail }, JWT_SECRET,{
      expiresIn:"15m",
    });

    if (res.statusCode === 200) {
      return res.json({ status: "ok", data: token });
    } else {
      return res.json({ error: "error" });
    }
  }
  res.json({ status: "error", error: "InValid Password" });
});

//UserData
app.post("/userdata", async (req, res) => {
  const { token } = req.body;
  try {
    const user = jwt.verify(token, JWT_SECRET, (err, res) => {
      if (err) {
        return "token expired";
      }
      return res;
    });
    console.log(user);
    if (user == "token expired") {
      return res.send({ status: "error", data: "token expired" });
    }

    //const useremail = user.workemail;
    User.findOne({ workemail: user.workemail })
  .then((data) => {
    res.send({ status: "ok", data: data });
  })
  .catch((error) => {
    res.send({ status: "error", data: error });
  });
  } catch (error) { }
});

//Investor SignUp API
require("./investorDetails");

const Investor = mongoose.model("InvestorInfo");
app.post("/signup-investor" ,async (req,res)=>{
  const { investorcompanyName,
    firstName,
    lastName,
    emailid,
    mobileNo,
    password,
    about,
    website,
    linkedin,
    location,
    investmentSector } =
    req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    await Investor.create({
    investorcompanyName,
    firstName,
    lastName,
    emailid,
    mobileNo,
    password:hashedPassword,
    about,
    website,
    linkedin,
    location,
    investmentSector,
    });
    res.send({ status: "ok" });
  } catch (error) {
    res.send({ status: "error" });
    console.log(error);
  }
});

//Login Investor API

app.post("/login-investor", async (req, res) => {
  const { emailid,password} =req.body;
  const investor = await Investor.findOne({emailid});
  if(!investor){
    return res.json({error:"User Not Found"});
  }
  if (await bcrypt.compare(password, investor.password)) {
    const token = jwt.sign({ emailid: investor.emailid }, JWT_SECRET,{
      expiresIn:"59m",
    });

    if (res.statusCode === 200) {
      return res.json({ status: "ok", data: token });
    } else {
      return res.json({ error: "error" });
    }
  }
  res.json({ status: "error", error: "InValid Password" });
});

//investor fetching pitches data

app.post('/investordata', async (req, res) => {
  
    const { token } = req.body;
    try {
      const user = jwt.verify(token, JWT_SECRET, (err, res) => {
        if (err) {
          return "token expired";
        }
        return res;
      });
      console.log(user);
      if (user == "token expired") {
        return res.send({ status: "error", data: "token expired" });
      }
  
      //const useremail = user.workemail;
      PitchBusiness.find({ investorcompanyName: user.investorcompanyName })
    .then((data) => {
      res.send({ status: "ok", data: data });
    })
    .catch((error) => {
      res.send({ status: "error", data: error });
    });
    } catch (error) { }
  });


//forgot Password


//ContactUs API
require("./contactUs");
const contact = mongoose.model("contactUs");
app.post('/contact', async(req,res)=>{
  const { fullName,email,message} =req.body;
  try{
    await contact.create({
      fullName,
      email,
      message,
    });
    res.send({status:"ok"});
  }
  catch(error){
    res.send({status:"error"});
  }
})

//Investor  Search
app.get('/investors', async (req, res) => {
  const { query } = req.query;

  try {
    const investors = await Investor.find({
      $or: [
        { investorcompanyName: { $regex: query, $options: 'i' } },
        { firstName: { $regex: query, $options: 'i' } },
      ],
    });
    console.log('Sending JSON data:', investors);
    res.json(investors);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});

//Startup Search
app.get('/startups', async (req, res) => {
  const { query } = req.query;

  try {
    const users = await User.find({
      $or: [
        { companyName: { $regex: query, $options: 'i' } },
        { firstName: { $regex: query, $options: 'i' } },
      ],
    });
    console.log('Sending JSON data:', users);
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});

//Mentors Search
app.get('/mentors', async (req, res) => {
  const { query } = req.query;

  try {
    const mentor = await Mentor.find({
      $or: [
        { jobPost: { $regex: query, $options: 'i' } },
        { fullName: { $regex: query, $options: 'i' } },
      ],
    });
    console.log('Sending JSON data:', mentor);
    res.json(mentor);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});
//Signup Mentor
require("./mentorDetails");
const Mentor = mongoose.model("MentorsInfo");
app.post('/signup-mentor' ,async(req,res)=>{
  const { fullName,jobPost,email,mobileNo,password,aboutInfo}= req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    await Mentor.create({
      fullName,
      jobPost,
      email,
      mobileNo,
      password:hashedPassword,
      aboutInfo,
    });
    res.send({ status: "ok" });
  } catch (error) {
    res.send({ status: "error" });
    console.log(error);
  }
});
//Login Mentor
app.post('/login-mentor' ,async(req,res)=>{
  const { email,password} =req.body;
  const muser = await Mentor.findOne({email});
  if(!muser){
    return res.json({error:"User Not Found"});
  }
  if (await bcrypt.compare(password, muser.password)) {
    const token = jwt.sign({ email: muser.email }, JWT_SECRET,{
      expiresIn:"15m",
    });

    if (res.statusCode === 200) {
      return res.json({ status: "ok", data: token });
    } else {
      return res.json({ error: "error" });
    }
  }
  res.json({ status: "error", error: "InValid Password" });
});

app.get('/mentors', async (req, res) => {
  try {
    const mentors = await Mentor.find();
    res.json(mentors);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

//Pitching business to Investor API
const pitchBusiness = mongoose.model("PitchBusiness");
app.post('/pitch-business' ,async(req,res)=>{
  try {
    const { workemail, investorcompanyName, leveloffunding, keynote } = req.body;

    const newPitchBusiness = new PitchBusiness({
      workemail,
      investorcompanyName,
      leveloffunding,
      keynote,
    });

    // Save the document to the database
    await newPitchBusiness.save();

    res.status(201).json({ status: 'ok' });
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    res.status(500).json({ status: 'error' });
  }
});

//Listen
app.listen(5000, () => {
  console.log("Server started");
});

