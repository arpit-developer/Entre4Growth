// const mongoose = require('mongoose');

// const pitchBusinessSchema = new mongoose.Schema({
//   workemail: String,
//   investorcompanyName: String,
//   leveloffunding:String,
//   keynote:String,
// },
// {
//   collection: "PitchBusiness",
// }
// );

// mongoose.model('PitchBusiness', pitchBusinessSchema);
const mongoose = require('mongoose');

const pitchBusinessSchema = new mongoose.Schema({
  workemail: String,
  investorcompanyName: String,
  leveloffunding: String,
  keynote: String,
});

// Define the 'PitchBusiness' model using the schema
const PitchBusiness = mongoose.model('PitchBusiness', pitchBusinessSchema);

module.exports = PitchBusiness; // Export the mod