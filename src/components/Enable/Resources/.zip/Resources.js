import React from "react";
import { useState, useEffect } from "react";
import { Card } from "react-bootstrap";
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./Resources.css";

export const Resources = () => {
  return (
    <div>
      <div className="resources">
        <Navbar expand="lg" className="header">
          <Navbar.Toggle aria-controls="basic-navbar-nav" />

          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ml-auto nav-links">
              <Nav.Link href="/resources">Articles</Nav.Link>
              <Nav.Link href="/visteblogs">Blogs</Nav.Link>
              <Nav.Link href="/vistpod">Pod Cast </Nav.Link>
              <Nav.Link href="/book">Book</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      </div>
      <div className="row">
        <div className="col-md-4">
          <div
            className="multi-carousel-item p-2"
            style={{ width: "25%", marginLeft: 0 }}
          >
            <div className="card">
              <div
                className="img_card"
                style={{
                  height: 175,
                  borderRadius: 8,
                  borderBottomLeftRadius: 0,
                  borderBottomRightRadius: 0,
                }}
              >
                <img
                  src="/articles/2_1.png"
                  className="card_img"
                  style={{
                    height: 175,
                    borderRadius: 8,
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                  }}
                  alt="Mentorship Hub"
                />
                <div className="card-img-overlay text-white pt-1">
                  <h5
                    className="sp-break line-2"
                    style={{ lineHeight: "1.5" }}
                  ></h5>
                </div>
              </div>
              <div className="card-body">
                <p
                  className=" sp-break line-3 text-sm"
                 
                >
                  <a href="First">How to Identify Your Ideal Customers</a>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div
            className="multi-carousel-item p-2"
            style={{ width: "25%", marginLeft: 0 }}
          >
            <div className="card">
              <div
                className="img_card"
                style={{
                  height: 175,
                  borderRadius: 8,
                  borderBottomLeftRadius: 0,
                  borderBottomRightRadius: 0,
                }}
              >
                <img
                  src="/articles/second.jpg"
                  className="card_img"
                  style={{
                    height: 175,
                    borderRadius: 8,
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                  }}
                  alt="Mentorship Hub"
                />
                <div className="card-img-overlay text-white pt-1">
                  <h5
                    className="sp-break line-2"
                    style={{ lineHeight: "1.5" }}
                  ></h5>
                </div>
              </div>
              <div className="card-body">
                <p
                  className=" sp-break line-3 text-sm"
                  style={{
                    fontSize: "0.875rem",
                    fontWeight: 400,
                    lineHeight: "1.43",
                    height: "auto",
                  }}
                >
                  <a href="Second">
                    7 Ways to Protect Your Small Business from Risk{" "}
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div
            className="multi-carousel-item p-2"
            style={{ width: "25%", marginLeft: 0 }}
          >
            <div className="card">
              <div
                className="img_card"
                style={{
                  height: 175,
                  borderRadius: 8,
                  borderBottomLeftRadius: 0,
                  borderBottomRightRadius: 0,
                }}
              >
                <img
                  src="/articles/factors-that-cause-business-failures.jpg"
                  className="card_img"
                  style={{
                    height: 175,
                    borderRadius: 8,
                    borderBottomLeftRadius: 0,
                    borderBottomRightRadius: 0,
                  }}
                  alt="Mentorship Hub"
                />
                <div className="card-img-overlay text-white pt-1">
                  <h5
                    className="sp-break line-2"
                    style={{ lineHeight: "1.5" }}
                  ></h5>
                </div>
              </div>
              <div className="card-body">
                <p
                  className=" sp-break line-3 text-sm"
                  style={{
                    fontSize: "0.875rem",
                    fontWeight: 400,
                    lineHeight: "1.43",
                    height: "auto",
                  }}
                >
                  <a href="Fourth">Top Five Reasons why Entrepreneurs Fail</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Resources;
